# Instagram-Auto-View-Story
A bot that makes all your friend's stories marked as seen.

* Author : @auliaahmad16 (Instagram)

## Tutorial on Termux [ANDROID]
	$ STAR THIS REPOSITORY!
	$ pkg install nodejs
	$ git clone https://github.com/auliaahmad165/Instagram-Auto-View-Story.git
	$ cd Instagram-Auto-View-Story
	$ unzip node_modules.zip
	$ node index.js
  
## Warning
	⚠ Use tools at your own risk.
	⚠ Use this Tool for personal use, not for sale.
	⚠ I am not responsible for your account using this tool.
	⚠ Make sure your account has been verified (Email & Telp).
